# StaticHandGestureRecognitionASL

Applied CNN model on American Sign Language dataset of images containing hand gestures and predicted corresponding Alphabet of the hand gesture with accuracy of 99.7%
